module com.example.examenhoy {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.examenhoy to javafx.fxml;
    exports com.example.examenhoy;
}