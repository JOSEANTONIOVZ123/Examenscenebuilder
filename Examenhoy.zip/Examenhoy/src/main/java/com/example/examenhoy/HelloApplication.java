package com.example.examenhoy;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class HelloApplication extends Application {

    private final ObservableList<User> userData = FXCollections.observableArrayList();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("User Management");

        TableView<User> table = new TableView<>();
        table.setEditable(true);

        TableColumn<User, String> nameCol = new TableColumn<>("Nombre");
        nameCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getName()));

        TableColumn<User, String> emailCol = new TableColumn<>("Correo");
        emailCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getEmail()));

        TableColumn<User, String> platformCol = new TableColumn<>("Plataforma");
        platformCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getPlatform()));

        TableColumn<User, String> adminCol = new TableColumn<>("Administrador");
        adminCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().isAdmin() ? "Yes" : "No"));

        TableColumn<User, String> versionCol = new TableColumn<>("Version software");
        versionCol.setCellValueFactory(data -> new SimpleStringProperty(String.valueOf(data.getValue().getVersion())));

        TableColumn<User, String> createdCol = new TableColumn<>("Hora y fecha");
        createdCol.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getCreatedAt()));

        table.getColumns().addAll(nameCol, emailCol, platformCol, adminCol, versionCol, createdCol);
        table.setItems(userData);

        TextField nameField = new TextField();
        nameField.setPromptText("Nombre");

        TextField emailField = new TextField();
        emailField.setPromptText("Correo");

        TextField platformField = new TextField();
        platformField.setPromptText("Plataforma");

        CheckBox adminCheckBox = new CheckBox("Es administrador");

        Spinner<Integer> versionSpinner = new Spinner<>(1, 5, 1);

        Button addButton = new Button("Añadir");
        addButton.setOnAction(e -> {
            String name = nameField.getText();
            String email = emailField.getText();
            String platform = platformField.getText();
            boolean isAdmin = adminCheckBox.isSelected();
            int version = versionSpinner.getValue();
            String createdAt = java.time.LocalDate.now().toString();

            User newUser = new User(name, email, platform, isAdmin, version, createdAt);
            userData.add(newUser);

            nameField.clear();
            emailField.clear();
            platformField.clear();
            adminCheckBox.setSelected(false);
            versionSpinner.getValueFactory().setValue(1);
        });

        Button clearButton = new Button("Vaciar");
        clearButton.setOnAction(e -> userData.clear());

        VBox vbox = new VBox();
        vbox.getChildren().addAll(table, nameField, emailField, platformField, adminCheckBox, versionSpinner, addButton, clearButton);

        Scene scene = new Scene(vbox);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
